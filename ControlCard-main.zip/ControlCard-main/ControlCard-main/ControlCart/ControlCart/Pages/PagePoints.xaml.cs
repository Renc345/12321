﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ControlCart.Pages;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePoints.xaml
    /// </summary>
    public partial class PagePoints : Page
    {
        private class Data
        {
            public object Title { get; set; }
            public List<Data> Subtitle { get; set; }
        }

        private readonly Pattern _pattern = new Pattern();
        public PagePoints(Pattern selectedPattern)
        {
            InitializeComponent();
            _pattern = selectedPattern;
            DataContext = _pattern;

            List<Data> data = new List<Data>();
            foreach (Points points in ControlCardSMEntities.GetContext().Points.Where(x => x.Id_Patern == _pattern.Id_Patern).ToList())
            {
                List<Data> subdatas= new List<Data>();
                foreach (Sub_Items sub_Items in ControlCardSMEntities.GetContext().Sub_Items.Where(x => x.Id_Points == points.Id_Points).ToList())
                    subdatas.Add(new Data() { Title = sub_Items.text_sub_items });
                Data data1 = new Data() { Title = points.text_points, Subtitle = subdatas };
                data.Add(data1);
            }
            treeView1.ItemsSource = data;
        }
        
    }
}
