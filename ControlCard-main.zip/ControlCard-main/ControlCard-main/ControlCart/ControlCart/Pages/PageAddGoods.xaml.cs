﻿using ControlCart.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlCart.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddGoods.xaml
    /// </summary>
    public partial class PageAddGoods : Page
    {
        private Goods _currentgoods = new Goods();
        public PageAddGoods(Goods selectedGoods)
        {
            InitializeComponent();
            if (selectedGoods != null)
                _currentgoods = selectedGoods;
            DataContext = _currentgoods;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
           
            if (_currentgoods.Id_Goods == 0)
                ControlCardSMEntities.GetContext().Goods.Add(_currentgoods);
            try
            {

                ControlCardSMEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
